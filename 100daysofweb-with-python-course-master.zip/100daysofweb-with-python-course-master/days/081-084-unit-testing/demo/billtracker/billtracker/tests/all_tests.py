import unittest

# noinspection PyUnresolvedReferences
from billtracker.tests.default.default_viewmodel_tests import *
# noinspection PyUnresolvedReferences
from billtracker.tests.default.default_view_tests import *
# noinspection PyUnresolvedReferences
from billtracker.tests.site_tests import *


class AllTests(unittest.TestCase):
    pass
