# noinspection PyUnresolvedReferences
import data.models.rentals
# noinspection PyUnresolvedReferences
import data.models.locations
# noinspection PyUnresolvedReferences
import data.models.scooters
# noinspection PyUnresolvedReferences
import data.models.users
