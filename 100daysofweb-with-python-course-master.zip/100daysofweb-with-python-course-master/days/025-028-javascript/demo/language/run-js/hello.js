function hello(name){
  return 'Hello ' + name;
}

console.log(hello('bob'));

