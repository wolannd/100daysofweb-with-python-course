Title: Let's get this party started!
Date: 2019-03-31 22:00
Category: Python
Tags: 100daysofweb, Python, Awesomeness
Slug: first_post
Authors: Julian
Summary: This is a summary of the first post written for our Pelican Blog. We're using this for the 100daysofweb course.

##Big heading for a big day!

This is the first paragrah of our article - huzzah!

We're writing this is in Markdown format so we can use two * symbols to indicate a **bold** formatted block of text.


###A slightly smaller header...

We can also use a single * around a block of text to indicate an *italicised* word.


###Let's throw an image in here

![PyBites Logo]({static}/images/pb-logo.png)

THE END! (Cool story bro!)
