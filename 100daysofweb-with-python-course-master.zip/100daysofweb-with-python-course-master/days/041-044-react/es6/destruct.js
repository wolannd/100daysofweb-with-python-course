const bite = {
  id: 1,
  title: 'sum of numbers',
  level: 'beginner',
  points: 3,
}

// destructure bite object
const { id, title, level, points } = bite;
console.log(id);
console.log(title);
console.log(level);
console.log(points);
