// if single line, omit return and {}
const myFunc = (name='stranger') => 'Hello ' + name;

console.log(myFunc());
console.log(myFunc('mike'));
