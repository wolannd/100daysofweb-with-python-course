import React, { Component } from 'react';

class App extends Component {

  render(){
    const hello = 'Hello world from React';
    return (
      <h1>{hello}</h1>
    )
  }
}
