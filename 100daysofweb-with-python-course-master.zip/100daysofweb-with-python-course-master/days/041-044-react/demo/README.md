# React Projects Code

In this folder you will find the React code for the [Tips API front-end](tips/) and the [Free Monkey (hangman) game](freemonkey/).
