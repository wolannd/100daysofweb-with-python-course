from program import app

if __name__ == '__main__':
    app.run(load_dotenv=False)
