from project_awesome import app
