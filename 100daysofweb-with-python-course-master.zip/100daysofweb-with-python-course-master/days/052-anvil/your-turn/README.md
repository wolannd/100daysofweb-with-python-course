# Day 52 Anvil

In this miscellaneous, 1-day lesson there is not a dedicated follow on exercise. This was a long one so watching the videos definitely covers the day's exercises. But feel free to play with Anvil over at:

[**talkpython.fm/anvil100**](https://talkpython.fm/anvil100)